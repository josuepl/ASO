#include "funciones.h"

int suma(int x, int y) {
    return x + y;
}

int resta(int x, int y) {
    return x - y;
}