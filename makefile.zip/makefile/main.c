#include <stdio.h>
#include "funciones.h"  // Incluye nuestro header

int main() {
    int a = 5, b = 3;
    
    printf("Suma: %d\n", suma(a, b));
    printf("Resta: %d\n", resta(a, b));
    
    return 0;
}